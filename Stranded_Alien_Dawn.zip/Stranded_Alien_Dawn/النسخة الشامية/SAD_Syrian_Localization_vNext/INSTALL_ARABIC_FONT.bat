@echo off
setlocal
cd /d "%~dp0"
echo Copying Windows Arial fonts for Syrian Arabic preview...
if not exist "Fonts" mkdir "Fonts"
for %%F in (arial.ttf arialbd.ttf ariali.ttf arialbi.ttf) do (
  if exist "%WINDIR%\Fonts\%%F" (
    copy /Y "%WINDIR%\Fonts\%%F" "Fonts\%%F" >nul
    echo   OK: %%F
  ) else (
    echo   MISSING: %%F
  )
)
echo Done. Enable Syrian Arabic preview alone, keep game language English, and restart the game.
pause
