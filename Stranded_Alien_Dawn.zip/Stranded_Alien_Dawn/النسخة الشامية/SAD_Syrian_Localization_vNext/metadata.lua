return PlaceObj("ModDef", {
  "title", "الترجمة الشامية — Stranded: Alien Dawn (تجريبية)",
  "description", "نسخة مستقلة قيد التطوير: حوارات شامية عامية ومراجعة للقوائم والشروحات. لا تفعّلها مع النسخة العربية القديمة بنفس الوقت.",
  "id", "SADSHAM01",
  "author", "Jamal",
  "version_major", 0,
  "version_minor", 1,
  "version", 1,
  "lua_revision", 373414,
  "saved_with_revision", 373414,
  "saved", 0,
})
