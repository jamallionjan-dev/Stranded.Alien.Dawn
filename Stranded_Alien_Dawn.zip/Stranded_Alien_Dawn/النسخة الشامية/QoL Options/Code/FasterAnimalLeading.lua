local mod_FasterAnimalLeading = false
local options

-- Speed settings
local SURVIVOR_RUN_MULTIPLIER = 1.0           
local MIN_DISTANCE_BUFFER = 3 * guim         -- 3 meters minimum distance from survivor
local STOP_DISTANCE_MULTIPLIER = 3           -- 3x - increased stop distance to prevent frequent stopping

-- Individual animal speed multipliers (tuned for balanced leading)
local ANIMAL_SPEED_MULTIPLIERS = {
    Ulfen = 2.5,     
    Boxer = 3.0,
    GreatDane = 3.0,
    Weirmaraner = 3.0,
    Draka = 1.0,   
    Shogu = 2.0,    
    Camel = 1.4,     
    Gujo = 2.0,      
    Tecatli = 2.5,     
    Shrieker_Manhunting = 1.8,
    Shrieker_Mother = 1.5,
    Scissorhands = 1.5,
    Scissorhands_Nesting = 1.5,
    Noth = 4.5,
    Juno = 1.0,
}

local function ApplySettings()
	if not options then
		options = CurrentModOptions
	end
	if not options then return end
	
	mod_FasterAnimalLeading = options:GetProperty("FasterAnimalLeading")
end

local function ModOptions(id)
	if id and id ~= CurrentModId then
		return
	end
	ApplySettings()
end

OnMsg.ApplyModOptions = ModOptions
OnMsg.ModsReloaded = ModOptions
OnMsg.GameStarted = ApplySettings
OnMsg.LoadGame = ApplySettings

-- Hook Human:ResolveWalkPace to force running when leading animals
local original_ResolveWalkPace = Human.ResolveWalkPace
if original_ResolveWalkPace then
	function Human:ResolveWalkPace(target)
		if not mod_FasterAnimalLeading then
			return original_ResolveWalkPace(self, target)
		end
		
		-- Check if this human is currently leading an animal
		local is_leading = false
		for _, animal in ipairs(UIPlayer.labels.TamedAnimals or empty_table) do
			if animal.interacting_with == self and animal.command == "CmdFollowLeader" then
				is_leading = true
				break
			end
		end
		
		if is_leading then
			return "Run"
		end
		
		return original_ResolveWalkPace(self, target)
	end
end

-- Hook Unit:CmdFollowLeader to store original movement_adjust
local original_CmdFollowLeader = Unit.CmdFollowLeader
if original_CmdFollowLeader then
	function Unit:CmdFollowLeader()
		if mod_FasterAnimalLeading and self:IsKindOf("UnitAnimal") then
			-- Store original movement_adjust
			if not self.leading_original_movement_adjust then
				self.leading_original_movement_adjust = self.movement_adjust or 1000
			end
		end
		
		return original_CmdFollowLeader(self)
	end
end

-- Hook Unit:FollowLeaderStep to apply speed continuously
local original_FollowLeaderStep = Unit.FollowLeaderStep
if original_FollowLeaderStep then
	function Unit:FollowLeaderStep(leader, min_dist, max_dist)
		if not mod_FasterAnimalLeading or not self:IsKindOf("UnitAnimal") then
			return original_FollowLeaderStep(self, leader, min_dist, max_dist)
		end
		
		-- Find the appropriate multiplier for this animal class
		local multiplier = ANIMAL_SPEED_MULTIPLIERS[self.class] or 4.0
		
		-- Reapply movement_adjust continuously
		if self.leading_original_movement_adjust then
			local new_adjust = self.leading_original_movement_adjust * multiplier
			self.movement_adjust = new_adjust
			if self.UpdateMoveSpeed then self:UpdateMoveSpeed() end
		end
		
		-- Modify distances to prevent bumping
		local adjusted_min_dist = min_dist + MIN_DISTANCE_BUFFER
		local adjusted_max_dist = max_dist + MIN_DISTANCE_BUFFER
		
		-- Call original with adjusted distances
		return original_FollowLeaderStep(self, leader, adjusted_min_dist, adjusted_max_dist)
	end
end

-- Hook to clean up animal speed when leading ends
local original_OnAbandonLeader = Unit.OnAbandonLeader
if original_OnAbandonLeader then
	function Unit:OnAbandonLeader()
		if mod_FasterAnimalLeading and self:IsKindOf("UnitAnimal") then
			if self.leading_original_movement_adjust then
				self.movement_adjust = self.leading_original_movement_adjust
				if self.UpdateMoveSpeed then self:UpdateMoveSpeed() end
				self.leading_original_movement_adjust = nil
			end
		end
		
		if original_OnAbandonLeader then
			return original_OnAbandonLeader(self)
		end
	end
end

-- Hook LeadAnimalActivityObject:InteractWithAnimal to implement faster leading
local original_LeadAnimalInteractWithAnimal = LeadAnimalActivityObject and LeadAnimalActivityObject.InteractWithAnimal
if original_LeadAnimalInteractWithAnimal then
	function LeadAnimalActivityObject:InteractWithAnimal(unit, activity, skill_level, efficiency)
		local animal = self:GetActivityTarget()
		
		-- Call original to cancel training and check movement
		animal:CancelTrainingActivity("reset")
		if not animal:CanMove() then
			return
		end
		
		-- Only apply speed modifications if toggle is enabled
		if mod_FasterAnimalLeading then
			
			-- Store original pfclass values
			local old_unit_pfclass = unit.pfclass
			local old_animal_pfclass = animal.pfclass
			local lead_pfclass = animal.pfclass_tamed_lead or animal.pfclass
			
			local pos
			local reached
			
			-- Enhanced destructor with speed restoration
			local dtors = unit:PushDestructor(function(unit)
				if unit.UpdateMoveSpeed then unit:UpdateMoveSpeed() end
				
				-- Restore animal movement_adjust
				if animal.leading_original_movement_adjust then
					animal.movement_adjust = animal.leading_original_movement_adjust
					if animal.UpdateMoveSpeed then animal:UpdateMoveSpeed() end
					animal.leading_original_movement_adjust = nil
				end
				
				-- Restore pfclass
				unit.pfclass = old_unit_pfclass
				animal.pfclass = old_animal_pfclass
				unit.OnGotoStep = nil
				animal.OnAbandonLeader = nil
				
				if animal.command == "CmdFollowLeader" then
					animal:SetLeader(false, true)
					if reached then
						-- the animal is probably a bit behind, make it go to the desired location
						animal:TrySetCommand("CmdGotoPos", pos, lead_pfclass)
						return
					end
					animal:TrySetCommand("Idle")
				else
					animal:SetLeader()
				end
			end)
			
			-- Set up leader abandonment
			animal.OnAbandonLeader = function(animal)
				
				-- Restore animal movement_adjust
				if animal.leading_original_movement_adjust then
					animal.movement_adjust = animal.leading_original_movement_adjust
					if animal.UpdateMoveSpeed then animal:UpdateMoveSpeed() end
					animal.leading_original_movement_adjust = nil
				end
				
				self:delete()
			end
			
			-- Set pfclass for pathfinding
			unit.pfclass = lead_pfclass
			animal.pfclass = lead_pfclass
			animal:SetLeader(unit, "keep command")
			
			if not animal:CanSetCommand("CmdDraftMode") then
				unit:PopAndCallDestructor(dtors)
				return false
			end
			
			animal:SetCommand("CmdFollowLeader")
			animal.roam_start_pos = nil
			
			-- Enhanced distance calculation - increased stop distance
			local min_dist, max_dist = animal:GetMinMaxLeaderDist()
			local stop_dist = max_dist * STOP_DISTANCE_MULTIPLIER + MIN_DISTANCE_BUFFER
			
			-- Lead the animal to the designated spot
			local Sleep = Sleep
			local orig_method = unit.OnGotoStep
			
			unit.OnGotoStep = function(unit, ...)
				if not IsCloser(unit, animal, stop_dist) then
					return true
				end
				return orig_method(unit, ...)
			end
			
			while true do
				if IsCloser(unit, animal, stop_dist) then
					local reached, status = unit:Goto(self.lead_target_pos)
					if reached or status < 0 then
						-- reached the destination or failed
						if status == const.pfFailed then
							CreateFloatingText(self, T(298447844299, "Can't reach"), "FloatingNegative")
						end
						break
					end
				else -- animal is lagging behind, wait for it
					Sleep(unit:TimeToInterpolationEnd())
					if unit:Random(2) == 0 then
						unit:PlayMomentTrackedAnim("standing_Beckoning")
					else
						unit:PlayIdleAnim(2000)
					end
				end
			end
			
			reached = true
			pos = unit:GetPos()
			unit:PopAndCallDestructor(dtors)
			
			unit:Face(animal, 200)
			unit:PlayIdleAnim(2000)
			
			return true
		else
			-- Toggle disabled, use original behavior
			local old_unit_pfclass = unit.pfclass
			local old_animal_pfclass = animal.pfclass
			local lead_pfclass = animal.pfclass_tamed_lead or animal.pfclass
			local pos
			local reached
			
			local dtors = unit:PushDestructor(function(unit)
				unit.pfclass = old_unit_pfclass
				animal.pfclass = old_animal_pfclass
				unit.OnGotoStep = nil
				animal.OnAbandonLeader = nil
				
				if animal.command == "CmdFollowLeader" then
					animal:SetLeader(false, true)
					if reached then
						animal:TrySetCommand("CmdGotoPos", pos, lead_pfclass)
						return
					end
					animal:TrySetCommand("Idle")
				else
					animal:SetLeader()
				end
			end)
			
			animal.OnAbandonLeader = function(animal)
				self:delete()
			end
			
			unit.pfclass = lead_pfclass
			animal.pfclass = lead_pfclass
			animal:SetLeader(unit, "keep command")
			
			if not animal:CanSetCommand("CmdDraftMode") then
				unit:PopAndCallDestructor(dtors)
				return false
			end
			
			animal:SetCommand("CmdFollowLeader")
			animal.roam_start_pos = nil
			
			local min_dist, max_dist = animal:GetMinMaxLeaderDist()
			local stop_dist = max_dist * 3 / 2
			
			local Sleep = Sleep
			local orig_method = unit.OnGotoStep
			
			unit.OnGotoStep = function(unit, ...)
				if not IsCloser(unit, animal, stop_dist) then
					return true
				end
				return orig_method(unit, ...)
			end
			
			while true do
				if IsCloser(unit, animal, stop_dist) then
					local reached, status = unit:Goto(self.lead_target_pos)
					if reached or status < 0 then
						if status == const.pfFailed then
							CreateFloatingText(self, T(298447844299, "Can't reach"), "FloatingNegative")
						end
						break
					end
				else
					Sleep(unit:TimeToInterpolationEnd())
					if unit:Random(2) == 0 then
						unit:PlayMomentTrackedAnim("standing_Beckoning")
					else
						unit:PlayIdleAnim(2000)
					end
				end
			end
			
			reached = true
			pos = unit:GetPos()
			unit:PopAndCallDestructor(dtors)
			
			unit:Face(animal, 200)
			unit:PlayIdleAnim(2000)
			
			return true
		end
	end
end
