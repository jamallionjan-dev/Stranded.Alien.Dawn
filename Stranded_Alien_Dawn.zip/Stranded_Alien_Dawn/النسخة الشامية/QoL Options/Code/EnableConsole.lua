local mod_EnableConsole
local options

-- Store original function
local origAreCheatsEnabled = AreCheatsEnabled

function AreCheatsEnabled()
	return origAreCheatsEnabled() or ConsoleEnabled
end

local function ApplyConsoleSettings()
	if not options then
		options = CurrentModOptions
	end
	if not options then return end
	
	mod_EnableConsole = options:GetProperty("EnableConsole")
	
	-- Enable console functionality
	ConsoleEnabled = mod_EnableConsole
end

local function ModOptions(id)
	if id and id ~= CurrentModId then
		return
	end
	ApplyConsoleSettings()
end

-- Apply settings at various game events
OnMsg.ApplyModOptions = ModOptions
OnMsg.ModsReloaded = ModOptions
OnMsg.GameStarted = ApplyConsoleSettings
OnMsg.LoadGame = ApplyConsoleSettings
OnMsg.NewGame = ApplyConsoleSettings