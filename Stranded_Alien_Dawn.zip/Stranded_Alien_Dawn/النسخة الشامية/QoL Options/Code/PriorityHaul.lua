local mod_PriorityHaul
local options
local PriorityHaulResources = {}  -- Using handles as keys
_G.PriorityHaulModEnabled = false  -- Global variable for template access

local function ApplySettings()
	if not options then
		options = CurrentModOptions
	end
	if not options then return end
	
	mod_PriorityHaul = options:GetProperty("PriorityHaul")
	_G.PriorityHaulModEnabled = mod_PriorityHaul or false
end

local function ModOptions(id)
	if id and id ~= CurrentModId then
		return
	end
	ApplySettings()
end

OnMsg.ApplyModOptions = ModOptions
OnMsg.ModsReloaded = ModOptions
OnMsg.GameStarted = ApplySettings
OnMsg.LoadGame = ApplySettings
OnMsg.NewGame = ApplySettings

-- Track priority resources using handles
function IsResourceMarkedForPriority(resource_pile)
	if not mod_PriorityHaul then return false end
	if not IsValid(resource_pile) then return false end
	return PriorityHaulResources[resource_pile.handle] or false
end

function SetResourcePriority(resource_pile, priority)
	if not mod_PriorityHaul then return end
	if not IsValid(resource_pile) then return end
	
	PriorityHaulResources[resource_pile.handle] = priority or nil
	ObjModified(resource_pile)
end

function ClearPriorityResources()
	PriorityHaulResources = {}
end

-- Hook into WorkArea:GetClosestValidSupplyRequest to prioritize marked resources
local original_GetClosestValidSupplyRequest = WorkArea.GetClosestValidSupplyRequest

function WorkArea:GetClosestValidSupplyRequest(unit, max_demand_dist, supply_max_dist)
	if not mod_PriorityHaul then 
		return original_GetClosestValidSupplyRequest(self, unit, max_demand_dist, supply_max_dist)
	end
	
	-- First try to find priority resources
	local priority_filter = function(resource, demand_bld, req_bld)
		if not demand_bld:CanTakeResourceFrom(req_bld) then return false end
		local visual_bld = req_bld:GetVisualBuilding(unit)
		return IsValid(visual_bld) and IsKindOf(visual_bld, "ResourcePile") and IsResourceMarkedForPriority(visual_bld)
	end
	
	local priority_req = Request_GetClosestValidSupplyRequest(
		self.supply_queues, self.demand_queues, unit, supply_max_dist,
		CheckSupplyVisualBuilding, CheckDemandVisualBuilding, priority_filter)
	
	if priority_req then
		return priority_req
	end
	
	-- Fall back to normal selection
	return original_GetClosestValidSupplyRequest(self, unit, max_demand_dist, supply_max_dist)
end

-- Hook into ResourcePile.CreateBinActions to add priority haul button for multi-selection
local original_CreateBinActions = ResourcePile.CreateBinActions

function ResourcePile.CreateBinActions(bin, host)
	if not mod_PriorityHaul then 
		return original_CreateBinActions(bin, host)
	end
	
	-- Check if all objects in bin are ResourcePiles
	local all_resource_piles = true
	for _, obj in ipairs(bin) do
		if not IsValid(obj) or not IsKindOf(obj, "ResourcePile") then
			all_resource_piles = false
			break
		end
	end
	
	if not all_resource_piles then 
		return original_CreateBinActions(bin, host)
	end
	
	-- Check if all are marked for priority
	local all_priority = true
	for _, obj in ipairs(bin) do
		if not IsResourceMarkedForPriority(obj) then
			all_priority = false
			break
		end
	end
	
	local action_name = all_priority and T(123456789019, "ﻞﻘﻨﻟﺍ ﺔﻳﻮﻟﻭﺃ ﺀﺎﻐﻟﺇ") or T(169665047220, "ﺔﻳﻮﻟﻭﺄﺑ ﻞﻘﻧ")
	local icon = all_priority and "Mod/pWiJXv/UI/Delivery_Priority_Cancel" or "Mod/pWiJXv/UI/Delivery_Priority"
	local rollover_text = all_priority and T(123456789020, "ﺩﺭﺍﻮﻤﻟﺎﻫ ﻞﻘﻧ ﺔﻳﻮﻟﻭﺃ ﺀﺎﻐﻟﺇ") or T(123456789021, "ﻞﻘﻨﻟﺎﺑ ﺔﻳﻮﻟﻭﺃ ﺩﺭﺍﻮﻤﻟﺎﻫ ﺀﺎﻄﻋﺇ")
	
	XAction:new({
		ActionId = "idPriorityHaulMulti",
		ActionSortKey = "100",
		ActionName = action_name,
		ActionIcon = icon,
		ActionToolbar = "ip_actions",
		RolloverTemplate = "Rollover",
		RolloverText = rollover_text,
		OnAction = function(self, host, source, ...)
			for _, obj in ipairs(bin) do
				if IsValid(obj) and IsKindOf(obj, "ResourcePile") then
					local current_priority = IsResourceMarkedForPriority(obj)
					SetResourcePriority(obj, not current_priority)
					ObjModified(obj)
				end
			end
		end,
	}, host)
	
	-- Call original after adding our action
	original_CreateBinActions(bin, host)
end