local mod_SkipIntroVideos
local options

local function ApplySettings()
	if not options then
		options = CurrentModOptions
	end
	if not options then return end
	
	mod_SkipIntroVideos = options:GetProperty("SkipIntroVideos")
	
	if mod_SkipIntroVideos then
		config.SkipIntro = true
	else
		config.SkipIntro = false
	end
end

local function ModOptions(id)
	if id and id ~= CurrentModId then
		return
	end
	ApplySettings()
end

OnMsg.ApplyModOptions = ModOptions
OnMsg.ModsReloaded = ModOptions
OnMsg.GameStarted = ApplySettings
OnMsg.LoadGame = ApplySettings
OnMsg.NewGame = ApplySettings

ApplySettings()

function OnMsg.NewGame(game)
	if config.SkipIntro then
		game.no_intro = true
	end
end