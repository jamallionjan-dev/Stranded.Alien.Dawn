function OnMsg.GameStarted()
	ApplyQoLUnlocks()
end

function OnMsg.LoadGame()
	ApplyQoLUnlocks()
end

function OnMsg.ApplyModOptions(id)
	if CurrentModId == id then
		ApplyQoLUnlocks()
	end
end

function ApplyQoLUnlocks()
	local options = CurrentModOptions
	if not options then return end
	
	if not options.UnlockBasicFieldResearch then
		return
	end
	
	local player = UIPlayer
	if not player or not player.research_center then return end
	
	-- Get current region
	local current_region = Region and Region.id or ""
	
	local techs_to_unlock = {
		-- Bushes (sticks)
		"FieldBushBroadleafBig",
		"FieldBushBroadleafSmall",
		"FieldBushFern",
		"FieldBushPalm",
		
		-- Wood trees only (exclude fruit/food trees)
		"FieldTreeBroadleaf",
		"FieldTreeBroadleafSmall",
		"FieldTreeEvergreen",
		"FieldTreeEvergreenSmall",
		"FieldTreeTropicalBig",
		"FieldTreeTropicalSmall",
		"FieldTreeOasis",
		"FieldTreePalm",
		"FieldTreePalmBig",
		
		-- Grasses (hay)
		"FieldBladegrass",
		"FieldGiantGrass",
		
		-- Dog
		"FieldDog",
		
		-- Manure
		"FieldResourceManure",
		
		-- Feathers
		"FieldResourceFeathers",
	}
	
	-- Apply unlocks with region checking
	for _, tech_id in ipairs(techs_to_unlock) do
		if not player.research_center:IsTechResearched(tech_id) then
			local tech = Techs[tech_id]
			if tech then
				-- Check if tech has region prerequisites
				local region_allowed = true
				if tech.LockPrerequisites then
					for _, prereq in ipairs(tech.LockPrerequisites) do
						-- CheckRegion is stored as a property, not a class
						if prereq.Region then
							-- Check if current region is in the allowed set
							if not prereq.Region[current_region] then
								region_allowed = false
								break
							end
						end
					end
				end
				
				-- Only unlock if region matches or no region restriction
				if region_allowed then
					ExecuteEffectList(tech)
					player.research_center:SetTechResearched(tech_id)
				end
			end
		end
	end
end