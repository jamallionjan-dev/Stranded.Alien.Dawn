function OnMsg.ClassesPostprocess()
    local options = CurrentModOptions
    if not options then return end
    
    local enabled = options:GetProperty("CustomDryingRackSlots")
    
    if Presets.XTemplate and Presets.XTemplate["Infopanel Sections"] then
        for i = #Presets.XTemplate["Infopanel Sections"], 1, -1 do
            local template = Presets.XTemplate["Infopanel Sections"][i]
            if enabled then
                if template.id == "tabOverview_Storage" then
                    table.remove(Presets.XTemplate["Infopanel Sections"], i)
                end
            else
                if template.id == "tabOverview_Storage_modded" then
                    table.remove(Presets.XTemplate["Infopanel Sections"], i)
                end
            end
        end
    end
end

function OnMsg.ModsReloaded()
    local options = CurrentModOptions
    if not options then return end
    
    local enabled = options:GetProperty("CustomDryingRackSlots")
    
    if Presets.XTemplate and Presets.XTemplate["Infopanel Sections"] then
        for i = #Presets.XTemplate["Infopanel Sections"], 1, -1 do
            local template = Presets.XTemplate["Infopanel Sections"][i]
            if enabled then
                if template.id == "tabOverview_Storage" then
                    table.remove(Presets.XTemplate["Infopanel Sections"], i)
                end
            else
                if template.id == "tabOverview_Storage_modded" then
                    table.remove(Presets.XTemplate["Infopanel Sections"], i)
                end
            end
        end
    end
end