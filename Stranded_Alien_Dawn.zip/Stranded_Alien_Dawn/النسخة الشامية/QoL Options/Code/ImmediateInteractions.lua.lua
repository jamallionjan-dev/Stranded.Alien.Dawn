-- Immediate Interactions Mod
-- Overrides manipulation activities to apply changes immediately when mod options are enabled

-- ============================================================================
-- DEVICE INTERACTIONS (Power, Circuits, Temperature, Battery)
-- ============================================================================

local original_TurnOnOff = NetSyncEvents.TurnOnOff

function NetSyncEvents.TurnOnOff(player, building, on)
	local settings = CurrentModOptions or {}
	local immediate_devices = settings.EnableImmediateDeviceInteraction
	local immediate_windows = settings.EnableImmediateWindowGateInteraction
	local immediate_traps = settings.EnableImmediateTrapInteraction
	local immediate_forcefields = settings.EnableImmediateForceFieldInteraction
	
	-- Check if this building type should have immediate interaction
	local is_window = IsKindOf(building, "SlabWindow")
	local is_gate = IsKindOf(building, "FortGate") or IsKindOf(building, "SlabDoor")
	local is_trap = IsKindOf(building, "SingleUseTrap") or IsKindOf(building, "BaseTrap")
	local is_forcefield = IsKindOf(building, "ForceFieldSection")
	
	local should_be_immediate = false
	if immediate_devices and not (is_window or is_gate or is_trap or is_forcefield) then
		should_be_immediate = true
	elseif immediate_windows and (is_window or is_gate) then
		should_be_immediate = true
	elseif immediate_traps and is_trap then
		should_be_immediate = true
	elseif immediate_forcefields and is_forcefield then
		should_be_immediate = true
	end
	
	if should_be_immediate and building:CanTurnOff() then
		-- Immediate mode: skip worker, apply change directly
		if building.ui_on ~= on then
			building.ui_on = on
		end
		if player and building.on ~= on then
			building.on = on  -- Apply immediately
			building:OnTurnOnOff(on)  -- Trigger effects
		else
			building:RemoveManipulationActivity("TurnOnOff")
		end
		ObjModified(building)
	else
		-- Normal mode: use original behavior
		original_TurnOnOff(player, building, on)
	end
end

-- ============================================================================
-- CIRCUIT CONNECTIONS
-- ============================================================================

local original_PowerComponent_rfnSetDeviceSmartConnection = PowerComponent.rfnSetDeviceSmartConnection

function PowerComponent:rfnSetDeviceSmartConnection(smart_conn_idx, new_smart_conn)
	local settings = CurrentModOptions or {}
	local immediate_devices = settings.EnableImmediateDeviceInteraction
	
	if immediate_devices then
		-- Immediate mode: apply circuit change directly
		if not self:CanStartManipulationActivity() then return end
		
		local has_second_smart_conn = self.HasSecondSmartConnection
		local ui_smart_conn_new, ui_smart_conn2_new = self.ui_smart_connection, self.ui_smart_connection2
		local curr_smart_conn, curr_smart_conn2 = self:GetSmartConnection(), self:GetSecondSmartConnection()
		
		if smart_conn_idx == 1 then
			if not has_second_smart_conn or new_smart_conn ~= self.ui_smart_connection2 then
				ui_smart_conn_new = new_smart_conn
			elseif new_smart_conn == curr_smart_conn2 then
				ui_smart_conn_new = curr_smart_conn2
				ui_smart_conn2_new = curr_smart_conn
			end
		else
			assert(has_second_smart_conn)
			if new_smart_conn ~= self.ui_smart_connection then
				ui_smart_conn2_new = new_smart_conn
			elseif new_smart_conn == curr_smart_conn then
				ui_smart_conn_new = curr_smart_conn2
				ui_smart_conn2_new = curr_smart_conn
			end
		end
		
		-- Apply the changes directly to power_element
		if self.power_element then
			if smart_conn_idx == 1 then
				self.power_element:SetSmartConnection(ui_smart_conn_new)
			elseif smart_conn_idx == 2 then
				self.power_element:SetSmartConnection2(ui_smart_conn2_new)
			end
		end
		
		-- Update UI values
		self.ui_smart_connection = ui_smart_conn_new
		if has_second_smart_conn then
			self.ui_smart_connection2 = ui_smart_conn2_new
		end
		
		-- Trigger the change notification
		self:OnUISmartConnectionChanged(ui_smart_conn_new, curr_smart_conn)
		ObjModified(self)
	else
		-- Normal mode: use original behavior
		return original_PowerComponent_rfnSetDeviceSmartConnection(self, smart_conn_idx, new_smart_conn)
	end
end

-- ============================================================================
-- TEMPERATURE SENSOR THRESHOLD
-- ============================================================================

local original_TemperatureSensorComponent_rfnSetSensorTemperatureThreshold = TemperatureSensorComponent.rfnSetSensorTemperatureThreshold

function TemperatureSensorComponent:rfnSetSensorTemperatureThreshold(temp)
	local settings = CurrentModOptions or {}
	local immediate_devices = settings.EnableImmediateDeviceInteraction
	
	if immediate_devices then
		-- Immediate mode: apply temperature change directly
		self.ui_sensor_temperature = temp
		self.SensorTemperature = temp  -- Apply immediately
		ObjModified(self)
	else
		-- Normal mode: use original behavior
		return original_TemperatureSensorComponent_rfnSetSensorTemperatureThreshold(self, temp)
	end
end

-- ============================================================================
-- HEAT SOURCE TARGET TEMPERATURE
-- ============================================================================

local original_HeatSourceComponent_rfnSetTargetTemperatureThreshold = HeatSourceComponent.rfnSetTargetTemperatureThreshold

function HeatSourceComponent:rfnSetTargetTemperatureThreshold(temp)
	local settings = CurrentModOptions or {}
	local immediate_devices = settings.EnableImmediateDeviceInteraction
	
	if immediate_devices then
		-- Immediate mode: apply temperature change directly
		self.ui_target_temperature = temp
		self.TargetTemperature = temp  -- Apply immediately
		ObjModified(self)
	else
		-- Normal mode: use original behavior
		return original_HeatSourceComponent_rfnSetTargetTemperatureThreshold(self, temp)
	end
end

-- ============================================================================
-- BATTERY SENSOR THRESHOLD
-- ============================================================================

local original_BatterySensorComponent_rfnSetBatteryLevelThreshold = BatterySensorComponent.rfnSetBatteryLevelThreshold

function BatterySensorComponent:rfnSetBatteryLevelThreshold(temp)
	local settings = CurrentModOptions or {}
	local immediate_devices = settings.EnableImmediateDeviceInteraction
	
	if immediate_devices then
		-- Immediate mode: apply battery level change directly
		self.ui_battery_level = temp
		self.BatteryLevel = temp  -- Apply immediately
		ObjModified(self)
	else
		-- Normal mode: use original behavior
		return original_BatterySensorComponent_rfnSetBatteryLevelThreshold(self, temp)
	end
end

-- ============================================================================
-- GATE MANUAL INTERACTION OVERRIDE
-- ============================================================================

local original_FortGate_ManuallyInteract = FortGate.ManuallyInteract

function FortGate:ManuallyInteract(human)
	local settings = CurrentModOptions or {}
	local immediate_windows = settings.EnableImmediateWindowGateInteraction
	
	if immediate_windows then
		-- Immediate mode: apply change directly
		NetSyncEvents.TurnOnOff(self.player, self, not self.on)
	else
		-- Normal mode: use original behavior
		return original_FortGate_ManuallyInteract(self, human)
	end
end

-- ============================================================================
-- TRAP MANUAL INTERACTION OVERRIDE
-- ============================================================================

if rawget(_G, "SingleUseTrap") and SingleUseTrap.ManuallyInteract then
	local original_SingleUseTrap_ManuallyInteract = SingleUseTrap.ManuallyInteract
	
	function SingleUseTrap:ManuallyInteract(human)
		local settings = CurrentModOptions or {}
		local immediate_traps = settings.EnableImmediateTrapInteraction
		
		if immediate_traps then
			-- Immediate mode: apply change directly
			NetSyncEvents.TurnOnOff(UIPlayer, self, not self.on)
		else
			-- Normal mode: use original behavior
			return original_SingleUseTrap_ManuallyInteract(self, human)
		end
	end
end

-- ============================================================================
-- FORCE FIELD MANUAL INTERACTION OVERRIDE
-- ============================================================================

if rawget(_G, "ForceFieldSection") and ForceFieldSection.ManuallyInteract then
	local original_ForceFieldSection_ManuallyInteract = ForceFieldSection.ManuallyInteract
	
	function ForceFieldSection:ManuallyInteract(human)
		local settings = CurrentModOptions or {}
		local immediate_forcefields = settings.EnableImmediateForceFieldInteraction
		
		if immediate_forcefields then
			-- Immediate mode: apply change directly
			NetSyncEvents.TurnOnOff(UIPlayer, self, not self.on)
		else
			-- Normal mode: use original behavior
			return original_ForceFieldSection_ManuallyInteract(self, human)
		end
	end
end