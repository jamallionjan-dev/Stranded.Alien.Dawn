local original_PGSurvivorsSelector_SetShip = PGSurvivorsSelector.SetShip

function PGSurvivorsSelector:SetShip(survivors_count, seed)
	local settings = CurrentModOptions or {}
	local enabled = settings.EnableStartingSurvivors
	local custom_limit = tonumber(settings.StartingSurvivorBonus)
	
	local default_count = GetMaxSurvivorsCount(Game and Game.scenario)
	
	if enabled and custom_limit and custom_limit > 0 then
		-- Use the minimum of default and custom limit for auto-fill
		survivors_count = Min(default_count, custom_limit)
	end
	
	local result = original_PGSurvivorsSelector_SetShip(self, survivors_count, seed)
	
	if enabled and custom_limit and custom_limit > 0 then
		self.max_recruited = custom_limit
	end
	
	return result
end