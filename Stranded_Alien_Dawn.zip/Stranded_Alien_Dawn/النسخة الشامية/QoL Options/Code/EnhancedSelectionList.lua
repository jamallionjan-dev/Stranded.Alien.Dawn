local mod_EnhancedSelectionList
local options

local function ApplySettings()
	if not options then
		options = CurrentModOptions
	end
	if not options then return end
	
	mod_EnhancedSelectionList = options:GetProperty("EnhancedSelectionList")
end

local function ModOptions(id)
	if id and id ~= CurrentModId then
		return
	end
	ApplySettings()
end

OnMsg.ApplyModOptions = ModOptions
OnMsg.ModsReloaded = ModOptions
OnMsg.GameStarted = ApplySettings
OnMsg.LoadGame = ApplySettings
OnMsg.NewGame = ApplySettings

-- Debug: Check if our template is loaded
function OnMsg.ClassesPostprocess()
	if XTemplates.tabOverview_Multiselection_Modded then
		print("Enhanced Selection List: Custom template loaded successfully")
	else
		print("Enhanced Selection List: Custom template NOT found")
	end
end