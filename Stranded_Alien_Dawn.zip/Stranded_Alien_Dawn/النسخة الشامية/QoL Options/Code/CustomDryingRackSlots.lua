local mod_CustomDryingRackSlots
local options

local function ApplySettings()
    if not options then
        options = CurrentModOptions
    end
    if not options then return end
    
    mod_CustomDryingRackSlots = options:GetProperty("CustomDryingRackSlots")
    _G.CustomDryingRackSlotsEnabled = mod_CustomDryingRackSlots
end

local function ModOptions(id)
    if id and id ~= CurrentModId then
        return
    end
    ApplySettings()
end

OnMsg.ApplyModOptions = ModOptions
OnMsg.ModsReloaded = ModOptions
OnMsg.GameStarted = ApplySettings
OnMsg.LoadGame = ApplySettings
OnMsg.NewGame = ApplySettings
OnMsg.ClassesPostprocess = ApplySettings

-- Add custom slot limits property to StorageDepotComponent
function OnMsg.ClassesBuilt()
    if StorageDepotComponent then
        table.insert(StorageDepotComponent.properties, {
            category = "Storage",
            id = "custom_drying_rack_slots",
            name = "Custom Drying Rack Slots",
            editor = "table",
            default = false,
            read_only = true,
        })
    end
end

-- Check if building is a large drying rack
function IsLargeDryingRack(obj)
    return IsValid(obj) and (IsKindOf(obj, "DryingRackLarge") or IsKindOf(obj, "DryingRackLarge_ScrapMetal"))
end

-- Get custom slot limit for a specific resource
function GetCustomSlotLimit(building, res)
    if not IsValid(building) then return nil end
    local slots = building.custom_drying_rack_slots
    if not slots then return nil end
    return slots[res]
end

-- Set custom slot limit for a specific resource
function SetCustomSlotLimit(building, res, limit)
    if not IsValid(building) then return end
    if not building.custom_drying_rack_slots then
        building.custom_drying_rack_slots = {}
    end
    building.custom_drying_rack_slots[res] = limit
end

-- Get total allocated slots for a building
function GetTotalAllocatedSlots(building)
    if not IsValid(building) then return 0 end
    local slots = building.custom_drying_rack_slots
    if not slots then return 0 end
    local total = 0
    for _, limit in pairs(slots) do
        total = total + limit
    end
    return total
end

-- Check if a resource is disabled
function IsResourceDisabled(building, res)
    return building.disabled_resources and building.disabled_resources[res]
end

-- Initialize slot limits for a new building (equal distribution)
function InitializeDryingRackSlotLimits(building)
    if not IsValid(building) then return end
    if not IsLargeDryingRack(building) then return end
    
    if building.custom_drying_rack_slots then return end
    
    local accepted = building.accepted_res or {}
    local count = #accepted
    if count == 0 then return end
    
    local slots_per_res = (building.stack_count / count) // 1
    building.custom_drying_rack_slots = {}
    
    for _, res in ipairs(accepted) do
        building.custom_drying_rack_slots[res] = slots_per_res
    end
end

function OnMsg.ClassesPostprocess()
    local options = CurrentModOptions
    if not options then return end
    
    local enabled = options:GetProperty("CustomDryingRackSlots")
    
    if Presets.XTemplate and Presets.XTemplate["Infopanel Sections"] then
        for i = #Presets.XTemplate["Infopanel Sections"], 1, -1 do
            local template = Presets.XTemplate["Infopanel Sections"][i]
            if enabled then
                if template.id == "tabOverview_Storage" then
                    table.remove(Presets.XTemplate["Infopanel Sections"], i)
                end
            else
                if template.id == "tabOverview_Storage_modded" then
                    table.remove(Presets.XTemplate["Infopanel Sections"], i)
                end
            end
        end
    end
end

function OnMsg.ModsReloaded()
    local options = CurrentModOptions
    if not options then return end
    
    local enabled = options:GetProperty("CustomDryingRackSlots")
    
    if Presets.XTemplate and Presets.XTemplate["Infopanel Sections"] then
        for i = #Presets.XTemplate["Infopanel Sections"], 1, -1 do
            local template = Presets.XTemplate["Infopanel Sections"][i]
            if enabled then
                if template.id == "tabOverview_Storage" then
                    table.remove(Presets.XTemplate["Infopanel Sections"], i)
                end
            else
                if template.id == "tabOverview_Storage_modded" then
                    table.remove(Presets.XTemplate["Infopanel Sections"], i)
                end
            end
        end
    end
end

-- Hook GetDesiredResAmount to cap at custom limits
local original_GetDesiredResAmount = StorageDepotComponent.GetDesiredResAmount
function StorageDepotComponent:GetDesiredResAmount(res)
    if not mod_CustomDryingRackSlots or not IsLargeDryingRack(self) then
        return original_GetDesiredResAmount(self, res)
    end
    
    -- Check game's built-in disabled_resources (from restrictions tab)
    if IsResourceDisabled(self, res) then return 0 end
    
    local custom_limit = GetCustomSlotLimit(self, res)
    if not custom_limit then
        return original_GetDesiredResAmount(self, res)
    end
    
    if custom_limit == 0 then
        return 0
    end
    
    -- Get the game's original desired amount
    local original_amount = original_GetDesiredResAmount(self, res)
    
    -- Cap it at our custom limit
    local max_amount = custom_limit * 100000
    
    return Min(original_amount, max_amount)
end

-- Initialize when building is done
function OnMsg.ObjDone(obj)
    if IsLargeDryingRack(obj) then
        InitializeDryingRackSlotLimits(obj)
    end
end

function UIChangeRawMeatSlots(obj, context, change)
    if not IsValid(obj) then return end
    local current = GetCustomSlotLimit(obj, "RawMeat") or 0
    local leather = GetCustomSlotLimit(obj, "LeatherRaw") or 0
    local smokeleaf = GetCustomSlotLimit(obj, "SmokeleafRaw") or 0
    local new_value = current + change
    
    local info = obj.res_stacks_info
    local occupied_stacks = 0
    for i = 1, obj:GetIPVisStorageTotalSlots() do
        local stack = info[i]
        if stack and stack.res == "RawMeat" and stack.amount > 0 then
            occupied_stacks = occupied_stacks + 1
        end
    end
    
    local new_total = new_value + leather + smokeleaf
    if new_total > 48 then
        new_value = 48 - leather - smokeleaf
    end
    if new_value < occupied_stacks then new_value = occupied_stacks end
    
    SetCustomSlotLimit(obj, "RawMeat", new_value)
    ObjModified(obj)
    obj:UpdateResPolicies()
end

function UIChangeLeatherRawSlots(obj, context, change)
    if not IsValid(obj) then return end
    local current = GetCustomSlotLimit(obj, "LeatherRaw") or 0
    local meat = GetCustomSlotLimit(obj, "RawMeat") or 0
    local smokeleaf = GetCustomSlotLimit(obj, "SmokeleafRaw") or 0
    local new_value = current + change
    
    local info = obj.res_stacks_info
    local occupied_stacks = 0
    for i = 1, obj:GetIPVisStorageTotalSlots() do
        local stack = info[i]
        if stack and stack.res == "LeatherRaw" and stack.amount > 0 then
            occupied_stacks = occupied_stacks + 1
        end
    end
    
    local new_total = new_value + meat + smokeleaf
    if new_total > 48 then
        new_value = 48 - meat - smokeleaf
    end
    if new_value < occupied_stacks then new_value = occupied_stacks end
    
    SetCustomSlotLimit(obj, "LeatherRaw", new_value)
    ObjModified(obj)
    obj:UpdateResPolicies()
end

function UIChangeSmokeleafRawSlots(obj, context, change)
    if not IsValid(obj) then return end
    local current = GetCustomSlotLimit(obj, "SmokeleafRaw") or 0
    local meat = GetCustomSlotLimit(obj, "RawMeat") or 0
    local leather = GetCustomSlotLimit(obj, "LeatherRaw") or 0
    local new_value = current + change
    
    local info = obj.res_stacks_info
    local occupied_stacks = 0
    for i = 1, obj:GetIPVisStorageTotalSlots() do
        local stack = info[i]
        if stack and stack.res == "SmokeleafRaw" and stack.amount > 0 then
            occupied_stacks = occupied_stacks + 1
        end
    end
    
    local new_total = new_value + meat + leather
    if new_total > 48 then
        new_value = 48 - meat - leather
    end
    if new_value < occupied_stacks then new_value = occupied_stacks end
    
    SetCustomSlotLimit(obj, "SmokeleafRaw", new_value)
    ObjModified(obj)
    obj:UpdateResPolicies()
end