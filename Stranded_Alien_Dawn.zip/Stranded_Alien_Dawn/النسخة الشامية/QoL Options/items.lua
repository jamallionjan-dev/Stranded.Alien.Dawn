return {
PlaceObj('ModItemOptionToggle', {
	'name', "EnableStartingSurvivors",
	'DisplayName', "ﺔﻳﺍﺪﺒﻟﺍ ﺪﻨﻋ ﺺﺼﺨﻣ ﻦﻴﺟﺎﻧ ﺩﺪﻋ ﻞﻴﻌﻔﺗ",
	'Help', ".ﻢﻬﻴﻓ ﺃﺪﺒﺘﺑ ﻲﻠﻟﺍ ﻦﻴﺟﺎﻨﻟﺍ ﺩﺪﻋ ﺩﺪﺤﺗ ﻚﻠﺤﻤﺴﻴﺑ",
}),
PlaceObj('ModItemOptionNumber', {
	'name', "StartingSurvivorBonus",
	'DisplayName', "ﺔﻳﺍﺪﺒﻟﺎﺑ ﻦﻴﺟﺎﻨﻟﺍ ﺩﺪﻋ",
	'DefaultValue', 4,
	'MinValue', 1,
	'MaxValue', 30,
}),
PlaceObj('ModItemCode', {
	'name', "StartingSurvivors",
	'CodeFileName', "Code/StartingSurvivors.lua",
}),
PlaceObj('ModItemOptionToggle', {
	'name', "SkipIntroVideos",
	'DisplayName', "ﻮﻳﺭﺎﻨﻴﺴﻟﺍ ﺔﻣﺪﻘﻣ ﺯﻭﺎﺠﺗ",
}),
PlaceObj('ModItemCode', {
	'name', "SkipIntroVideos",
	'CodeFileName', "Code/SkipIntroVideos.lua",
}),
PlaceObj('ModItemOptionToggle', {
	'name', "UnlockBasicFieldResearch",
	'DisplayName', "ﺔﻴﺳﺎﺳﻷﺍ ﻑﺎﺸﻜﺘﺳﻻﺍ ﺙﺎﺤﺑﺃ ﺢﺘﻓ",
	'Help', ".ﺶﻳﺮﻟﺍﻭ ﺩﺎﻤﺴﻟﺍﻭ ﺏﻼﻜﻟﺍﻭ ﺕﺍﺮﻴﺠﺸﻟﺍﻭ ﺭﺎﺠﺷﻷﺍ ﺙﺎﺤﺑﺃ ﺢﺘﻔﻴﺑ",
}),
PlaceObj('ModItemCode', {
	'name', "UnlockBasicFieldResearch",
	'CodeFileName', "Code/UnlockBasicFieldResearch.lua",
}),
PlaceObj('ModItemOptionToggle', {
	'name', "EnableConsole",
	'DisplayName', "ﺮﻣﺍﻭﻷﺍ ﺔﺣﻮﻟ ﻞﻴﻌﻔﺗ",
	'Help', ".ﺎﻬﺤﺘﻔﻟ ` ﺭﺯ ﻂﻐﺿﺍ .ﺐﻌﻠﻟﺍ ﺀﺎﻨﺛﺃ ﺮﻣﺍﻭﻷﺍ ﺔﺣﻮﻟ ﻞﻌّﻔﻴﺑ",
}),
PlaceObj('ModItemCode', {
	'name', "EnableConsole",
	'CodeFileName', "Code/EnableConsole.lua",
}),
PlaceObj('ModItemFolder', {
	'name', "Enhanced Selection List",
}, {
	PlaceObj('ModItemOptionToggle', {
		'name', "EnhancedSelectionList",
		'DisplayName', "ﺔﻨﺴّﺤﻣ ﺪﻳﺪﺤﺗ ﺔﻤﺋﺎﻗ",
		'Help', ".ﺪﻳﺪﺤﺘﻟﺍ ﻦﻣ ﺮﺻﺎﻨﻋ ﻞﻴﺸﺗ ﻰﺘﺣ ﺓﺩﺪﻌﺘﻤﻟﺍ ﺮﺻﺎﻨﻌﻟﺍ ﺓﺬﻓﺎﻧ ﻦﻤﺿ ﺮﻘﻨﻟﺍ ﻊﻣ Shift ﻡﺪﺨﺘﺳﺍ",
		'RequiresRestart', true,
		'DefaultValue', true,
	}),
	PlaceObj('ModItemCode', {
		'name', "Remove_tabOverview_Multiselection",
		'CodeFileName', "Code/Remove_tabOverview_Multiselection.lua",
	}),
	PlaceObj('ModItemCode', {
		'name', "EnhancedSelectionList",
		'CodeFileName', "Code/EnhancedSelectionList.lua",
	}),
	PlaceObj('ModItemXTemplate', {
		SortKey = 400,
		__is_kind_of = "InfopanelSection",
		group = "Infopanel Sections",
		id = "tabOverview_Multiselection_Modded",
		save_in = "Mod/pWiJXv",
		PlaceObj('XTemplateTemplate', {
			'__context_of_kind', "MultiSelectAdapter",
			'__template', "InfopanelSection",
		}, {
			PlaceObj('XTemplateFunc', {
				'name', "OnDelete",
				'func', function (self, ...)
					XSection.OnDelete(self, ...)
					-- remove the current bin name in a thread, which can be stopped if we reopen the same infopanel
					DeleteThread(g_ClearMultiselectBinThread)
					g_ClearMultiselectBinThread = false
					if CurrentMultiselectBin then
						CurrentMultiselectBinName = CurrentMultiselectBin.bin
						g_ClearMultiselectBinThread = CreateGameTimeThread(function()
							CurrentMultiselectBinName = false
						end)
						CurrentMultiselectBin = false
					end
					SetInviewHint("Multiselection")
				end,
			}),
			PlaceObj('XTemplateFunc', {
				'name', "Open",
				'func', function (self, ...)
					DeleteThread(g_ClearMultiselectBinThread)
					g_ClearMultiselectBinThread = false
					XSection.Open(self, ...)
					local old_func = self.parent.parent.OnDialogModeChange
					self.parent.parent.OnDialogModeChange = function(...)
						old_func(...)
						-- don't delete the selected bin when changing to another mode
						DeleteThread(g_ClearMultiselectBinThread)
						g_ClearMultiselectBinThread = false
					end
				end,
			}),
			PlaceObj('XTemplateWindow', {
				'__class', "XContentTemplateList",
				'BorderWidth', 0,
				'Background', RGBA(255, 255, 255, 0),
				'RelativeFocusOrder', "new-line",
				'FocusedBackground', RGBA(255, 255, 255, 0),
				'LeftThumbScroll', false,
				'CycleSelection', true,
				'ForceInitialSelection', true,
				'OnSelection', function (self, focused_item, selection)
					    local sel = self[selection[1] or false]
					    self:ResolveId("idActionsContext"):SetContext(sel and sel.context)
				end,
				'OnDoubleClick', function (self, item_idx)
					if self[item_idx] then self.context:Locate(self[item_idx].context) end
				end,
			}, {
				PlaceObj('XTemplateFunc', {
					'name', "RespawnContent",
					'func', function (self, ...)
						local scroll_area = self:GetScrollTarget()
						local offset_y = scroll_area and scroll_area.OffsetY
						local focused_item = self.focused_item
						XContentTemplate.RespawnContent(self)
						self:GenerateItemHashTable()
						if not focused_item then
							self:SetInitialSelection()
						else
							self:SetSelection(focused_item)
						end
						if (offset_y or 0) > 0 then
							scroll_area.pending_scroll_into_view = nil
							scroll_area:ScrollTo(0, offset_y, true)
						end
					end,
				}),
				PlaceObj('XTemplateFunc', {
					'name', "GetScrollTarget",
					'func', function (self, ...)
						local dlg = GetDialog(self)
						local scroll_area = dlg and dlg:ResolveId("idContent")
						return scroll_area or self
					end,
				}),
				PlaceObj('XTemplateFunc', {
					'name', "OnSetFocus",
					'func', function (self, ...)
						XContentTemplateList.OnSetFocus(self, ...)
						local item = Min(#self, self.focused_item or 1)
						if not table.find(self.selection, item) then
							self:SetSelection(item)
						end
					end,
				}),
				PlaceObj('XTemplateFunc', {
					'name', "OnShortcut(self, shortcut, source, ...)",
					'func', function (self, shortcut, source, ...)
						if shortcut == "DPadRight" then
							local action_bar = GetDialog(self):ResolveId("idActions")
							local focus = action_bar and action_bar:GetRelativeFocus(point(2, 0), "down")
							if focus then
								focus:SetFocus()
								return "break"
							end
						end
						if shortcut == "Down" then
							-- check if the focus is the last item
							local count = self:GetItemCount()
							if self.focused_item == count then
								-- check if we can scroll down
								local scroll_area = self:GetScrollTarget()
								local offset_y = scroll_area.OffsetY
								local max = scroll_area.scroll_range_y - scroll_area.content_box:sizey()
								if max > offset_y then
									scroll_area:ScrollDown()
									return "break"
								else
									scroll_area:ScrollTo(0, 0, true)
								end
							end
						end
						if shortcut == "Up" then
							-- check if the focus is the first item
							if self.focused_item == 1 then
								-- check if we can scroll up
								local scroll_area = self:GetScrollTarget()
								local offset_y = scroll_area.OffsetY
								if offset_y > 0 then
									scroll_area:ScrollUp()
									return "break"
								else
									scroll_area:ScrollTo(0, Max(0, scroll_area.scroll_range_y - scroll_area.content_box:sizey()), true)
								end
							end
						end
						return XContentTemplateList.OnShortcut(self, shortcut, source, ...)
					end,
				}),
				PlaceObj('XTemplateFunc', {
					'name', "SelectFirstValidItem",
					'func', function (self, ...)
						if CurrentMultiselectBinName then
							local idx
							if CurrentMultiselectBinName then
								local focus = self:ResolveId(CurrentMultiselectBinName)
								idx = table.find(self, focus)
							end
							if InfopanelLastFocusOrder and InfopanelLastFocusOrder ~= CurrentMultiselectBinName then
								-- some action was focused
								InfopanelLastFocusActionOrder = InfopanelLastFocusOrder
							end
							if idx then
								self:SetSelection(idx)
								return true
							end
						end
						return XContentTemplateList.SelectFirstValidItem(self)
					end,
				}),
				PlaceObj('XTemplateForEach', {
					'array', function (parent, context) return context:GetListItems() end,
					'__context', function (parent, context, item, i, n) return item end,
					'run_after', function (child, context, item, i, n, last)
						child:SetId(item.bin)
					end,
				}, {
					PlaceObj('XTemplateWindow', {
						'__class', "XListItem",
						'BorderWidth', 0,
						'LayoutMethod', "HList",
						'HandleMouse', true,
						'SelectionBackground', RGBA(89, 126, 141, 255),
					}, {
						PlaceObj('XTemplateFunc', {
							'name', "OnShortcut(self, shortcut, source, ...)",
							'func', function (self, shortcut, source, ...)
								if shortcut == "ButtonA" then
									self.parent.context:Locate(self.context)
									return "break"
								end
								return XListItem.OnShortcut(self, shortcut, source, ...)
							end,
						}),
						PlaceObj('XTemplateFunc', {
							'name', "OnMouseButtonDown(self, pos, button)",
							'func', function (self, pos, button)
								        if not terminal.IsKeyPressed(const.vkShift) then
								            return XContextControl.OnMouseButtonDown(self, pos, button)
								        end
								        
								        -- Get the actual objects from the selection bin
								        local bin = self.context
								        if not bin or type(bin) ~= "table" then
								            return XContextControl.OnMouseButtonDown(self, pos, button)
								        end
								        
								        -- Collect all objects in this bin
								        local objects_to_remove = {}
								        for i, obj in ipairs(bin) do
								            if IsValid(obj) then
								                table.insert(objects_to_remove, obj)
								            end
								        end
								        
								        if button == "L" then
								            -- Shift+Left click: Remove all objects in this bin from selection
								            for _, obj in ipairs(objects_to_remove) do
								                if IsInSelection(obj) then
								                    SelectionRemove(obj)
								                end
								            end
								            SelectionSubSel(false)
								            return "break"
								        elseif button == "R" then
								            -- Shift+Right click: Keep only objects in this bin, remove all others
								            local new_selection = objects_to_remove
								            SelectionSet(new_selection)
								            SelectionSubSel(false)
								            return "break"
								        end
								        
								        return XContextControl.OnMouseButtonDown(self, pos, button)
							end,
						}),
						PlaceObj('XTemplateFunc', {
							'name', "SetSelected(self, selected)",
							'func', function (self, selected)
								XListItem.SetSelected(self, selected)
								if selected then
									CurrentMultiselectBin = self.context
								end
								local dlg = GetDialog(self)
								local actions = dlg and dlg:ResolveId("idActions")
								if dlg and dlg:IsFocused(true) and (not selected or not actions or not actions:IsFocused(true)) then
									if actions then actions:SetFocus(false, true) end
									if self:IsFocused() ~= selected then
										self:SetFocus(selected)
									end
								end
							end,
						}),
						PlaceObj('XTemplateWindow', {
							'__class', "XText",
							'Padding', box(2, 2, 12, 2),
							'HAlign', "right",
							'MinWidth', 42,
							'TextStyle', "ItemTitle",
							'Translate', true,
							'Text', T(259279951926, --[[ModItemXTemplate tabOverview_Multiselection_Modded Text]] "<text_count>"),
							'TextHAlign', "right",
						}),
						PlaceObj('XTemplateWindow', {
							'__class', "XText",
							'TextStyle', "ItemTitle",
							'Translate', true,
							'Text', T(122749038431, --[[ModItemXTemplate tabOverview_Multiselection_Modded Text]] "<text>"),
						}),
						}),
					}),
				}),
			PlaceObj('XTemplateTemplate', {
				'__template', "MultiSelectionActionsContextWin",
				'OnContextUpdate', function (self, context, ...)
					            XContextWindow.OnContextUpdate(self, context, ...)
					            if not self:IsThreadRunning("RecreateActions") then
					                self:CreateThread("RecreateActions", function(self)
					                    Sleep(33)
					                    local host = GetActionsHost(self)
					                    if host.window_state ~= "destroying" and host.context then
					                        host.context:CreateBinActions(self.context, host)
					                        local bin_obj = table.fget(self.context, 1)
					                        if bin_obj then
					                            local cheats_toolbar = table.fget(host, "idSectionCheats", "idCheatsToolbar")
					                            for _, cheat in ipairs(cheats_toolbar) do
					                                local cheat_name = cheat.Id:sub(3, #cheat.Id)
					                                local visible = PropObjHasMember(bin_obj, "Cheat" .. cheat_name)
					                                             or PropObjHasMember(bin_obj, "AsyncCheat" .. cheat_name)
					                                cheat:SetVisible(visible)
					                                cheat:SetDock(not visible and "ignore")
					                            end
					                        end
					                        local last_bin = next(g_CurrentSelectionBin) and g_CurrentSelectionBin[1]
					                        Msg("SelectionBinChanged", self.context, last_bin)
					                    end
					                end, self)
					            end
					            if not GetUIStyleGamepad() and not HintsStack["Multiselection"] then
					                SetInviewHint("Multiselection", T(818039609123, "ﻂﻘﻓ ﺔﻋﻮﻤﺠﻤﻟﺎﻫ ﺀﺎﻘﺑﺇ :ﺔﻤﺋﺎﻘﻟﺍ ﻰﻠﻋ <right_click> + Shift<newline>ﺔﻋﻮﻤﺠﻤﻟﺍ ﺔﻟﺍﺯﺇ :ﺔﻤﺋﺎﻘﻟﺍ ﻰﻠﻋ <left_click> + Shift<newline>ﺪﻳﺪﺤﺘﻟﺍ ﻦﻣ ﺮﺼﻨﻌﻟﺍ ﺔﻟﺍﺯﺇ ﻭﺃ ﺔﻓﺎﺿﻹ <left_click> + Shift"), false, false, true)
					            end
				end,
			}),
			}),
	}),
	}),
PlaceObj('ModItemFolder', {
	'name', "Priority Haul",
}, {
	PlaceObj('ModItemOptionToggle', {
		'name', "PriorityHaul",
		'DisplayName', "ﺩﺭﺍﻮﻤﻟﺍ ﻞﻘﻧ ﺔﻳﻮﻟﻭﺃ",
		'Help', ".ﻞﻘﻨﻟﺎﺑ ﺔﻳﻮﻟﻭﺃ ﺓﺩﺪﺤﻤﻟﺍ ﺩﺭﺍﻮﻤﻟﺍ ﻲﻄﻌﻴﺑ ﺭﺯ ﻒﻴﻀﻴﺑ",
		'DefaultValue', true,
	}),
	PlaceObj('ModItemCode', {
		'name', "PriorityHaul",
		'CodeFileName', "Code/PriorityHaul.lua",
	}),
	PlaceObj('ModItemXTemplate', {
		RequireActionSortKeys = true,
		SortKey = 1,
		group = "Infopanel Actions",
		id = "IPActions_ResourcePile",
		save_in = "Mod/pWiJXv",
		PlaceObj('XTemplateGroup', {
			'__context_of_kind', "ResourcePile",
		}, {
			PlaceObj('XTemplateAction', {
				'ActionId', "PriorityHaul",
				'ActionSortKey', "0",
				'ActionName', T(169665047220, --[[ModItemXTemplate IPActions_ResourcePile ActionName]] "ﺔﻳﻮﻟﻭﺄﺑ ﻞﻘﻧ"),
				'ActionIcon', "Mod/pWiJXv/UI/Delivery_Priority.png",
				'ActionToolbar', "ip_actions",
				'ActionState', function (self, host)
					    if not _G.PriorityHaulModEnabled then return "hidden" end
					    
					    local target = host.context
					    if not IsValid(target) or not IsKindOf(target, "ResourcePile") then return "hidden" end
					    
					    if IsResourceMarkedForPriority(target) then
					        self.ActionIcon = "Mod/pWiJXv/UI/Delivery_Priority_Cancel"
					        self.RolloverText = T(123456789018, --[[ModItemXTemplate IPActions_ResourcePile RolloverText]] "ﺩﺭﻮﻤﻟﺎﻫ ﻞﻘﻧ ﺔﻳﻮﻟﻭﺃ ﺀﺎﻐﻟﺇ")
					        return "active"
					    else
					        self.ActionIcon = "Mod/pWiJXv/UI/Delivery_Priority"
					        self.RolloverText = T(123456789017, --[[ModItemXTemplate IPActions_ResourcePile RolloverText]] "ﻞﻘﻨﻟﺎﺑ ﺔﻳﻮﻟﻭﺃ ﺩﺭﻮﻤﻟﺎﻫ ﺀﺎﻄﻋﺇ")
					    end
					    return ""
				end,
				'OnAction', function (self, host, source, ...)
					    if not _G.PriorityHaulModEnabled then return end
					    
					    local target = host.context
					    if not IsValid(target) or not IsKindOf(target, "ResourcePile") then return end
					    
					    local current_priority = IsResourceMarkedForPriority(target)
					    SetResourcePriority(target, not current_priority)
					    ObjModified(target)
				end,
				'__condition', function (parent, context) return IsValid(context) and IsKindOf(context, "ResourcePile") and _G.PriorityHaulModEnabled end,
			}),
			}),
	}),
	}),
PlaceObj('ModItemFolder', {
	'name', "Custom Drying Rack Slots",
}, {
	PlaceObj('ModItemOptionToggle', {
		'name', "CustomDryingRackSlots",
		'DisplayName', "ﻒﻴﻔﺠﺘﻟﺍ ﻑﺭ ﺕﺎﻧﺎﺧ ﺺﻴﺼﺨﺗ",
		'Help', ".ﺩﺭﻮﻣ ﻉﻮﻧ ﻞﻜﻟ ﺕﺎﻧﺎﺨﻟﺍ ﺩﺪﻋ ﺪﻳﺪﺤﺘﻟ ﻡﺎﻈﻨﺑ ﺮﻴﺒﻜﻟﺍ ﻒﻴﻔﺠﺘﻟﺍ ﻑﺭ ﺔﻬﺟﺍﻭ ﻝﺪﺒﺘﺴﻴﺑ",
		'RequiresRestart', true,
	}),
	PlaceObj('ModItemCode', {
		'name', "Replace_tabOverview_Storage",
		'CodeFileName', "Code/Replace_tabOverview_Storage.lua",
	}),
	PlaceObj('ModItemCode', {
		'name', "CustomDryingRackSlots",
		'CodeFileName', "Code/CustomDryingRackSlots.lua",
	}),
	PlaceObj('ModItemXTemplate', {
		SortKey = 100,
		__is_kind_of = "InfopanelSection",
		group = "Infopanel Sections",
		id = "tabOverview_Storage_modded",
		save_in = "Mod/pWiJXv",
		PlaceObj('XTemplateGroup', {
			'__condition', function (parent, context)
				if IsKindOf(context, "StorageDepotComponent") then return true end
				return IsKindOf(context, "StoragePileInfopanelObject") and context:IsConstructionFinished()
			end,
		}, {
			PlaceObj('XTemplateTemplate', {
				'__condition', function (parent, context) return not IsKindOf(ResolvePropObj(context), "StoragePileInfopanelObject") end,
				'__template', "InfopanelSection",
			}, {
				PlaceObj('XTemplateWindow', {
					'__context', function (parent, context) return SubContext(context, {context:GetPropContext("StorageTempState")}) end,
					'__class', "XText",
					'HandleMouse', false,
					'TextStyle', "InfopanelText",
					'Translate', true,
					'Text', T(304898654079, --[[ModItemXTemplate tabOverview_Storage_modded Text]] "<IPStorageStateAndTempText>"),
					'ImageScale', 800,
				}),
				}),
			PlaceObj('XTemplateTemplate', {
				'__condition', function (parent, context)
					local obj = ResolvePropObj(context)
					    -- If this is a large drying rack, skip default UI (use custom instead)
					    if IsValid(obj) and (IsKindOf(obj, "DryingRackLarge") or IsKindOf(obj, "DryingRackLarge_ScrapMetal")) then
					        return false
					    end
					    return true
				end,
				'__template', "InfopanelSection",
				'Title', T(310065728931, --[[ModItemXTemplate tabOverview_Storage_modded Title]] "</em><IPVisStorageTotalSlots> / <IPVisStorageFilledSlots><em><right> ﻦﻳﺰﺨﺘﻟﺍ ﺕﺎﻧﺎﺧ"),
			}, {
				PlaceObj('XTemplateWindow', {
					'__class', "XContextWindow",
					'IdNode', true,
					'RolloverOnFocus', true,
					'RelativeFocusOrder', "new-line",
				}, {
					PlaceObj('XTemplateTemplate', {
						'__template', "RolloverLine",
					}),
					PlaceObj('XTemplateFunc', {
						'name', "OnShortcut(self, shortcut, source, ...)",
						'func', function (self, shortcut, source, ...)
							if shortcut == "LeftTrigger-DPadDown" then
								XGamepadShortcutPauseDisabled = true
								local context = self.context
								UIChangeAllowedStacks(ResolvePropObj(context), context, -1)
								return "break"
							end
							if shortcut == "LeftTrigger-DPadUp" then
								XGamepadShortcutPauseDisabled = true
								local context = self.context
								UIChangeAllowedStacks(ResolvePropObj(context), context, 1)
								return "break"
							end
							return XContextWindow.OnShortcut(self, shortcut, source, ...)
						end,
					}),
					PlaceObj('XTemplateFunc', {
						'name', "OnSetFocus(self, ...)",
						'func', function (self, ...)
							XContextWindow.OnSetFocus(self, ...)
							local tab = GetDialog(self):ResolveId("idFirstTab")
							local scroll_area = tab and tab:ResolveId("idContent")
							if scroll_area then
								scroll_area:ScrollIntoView(self)
							end
							SetInviewHint("AllowedStacks", T(249215620689, "ﺔﺣﻮﻤﺴﻤﻟﺍ ﺕﺎﻧﺎﺨﻟﺍ ﺪﻳﺪﺤﺘﻟ <DPadUpDown>+<LT>"))
						end,
					}),
					PlaceObj('XTemplateFunc', {
						'name', "OnKillFocus(self, ...)",
						'func', function (self, ...)
							XContextWindow.OnKillFocus(self, ...)
							SetInviewHint("AllowedStacks")
						end,
					}),
					PlaceObj('XTemplateWindow', {
						'comment', "slots",
						'__class', "XText",
						'HandleMouse', false,
						'TextStyle', "InfopanelText",
						'Translate', true,
						'Text', T(206701736912, --[[ModItemXTemplate tabOverview_Storage_modded Text]] "ﺔﺣﻮﻤﺴﻤﻟﺍ ﺕﺎﻧﺎﺨﻟﺍ"),
					}),
					PlaceObj('XTemplateTemplate', {
						'__template', "AmountControl",
						'HAlign', "right",
						'PressFunc', "UIChangeAllowedStacks",
					}, {
						PlaceObj('XTemplateFunc', {
							'name', "GetUIAmountText",
							'func', function (self, ...)
								return self.context:GetAllowedStackCount()
							end,
						}),
						PlaceObj('XTemplateFunc', {
							'name', "GetUIAmount(self, button)",
							'func', function (self, button)
								local context = self:GetContext()
								local obj = ResolvePropObj(context)
								local total = obj:GetIPVisStorageTotalSlots()
								if button.Id == "idLeft1" then
									return total >= 10 and -10
								elseif button.Id == "idLeft2" then
									return -1
								elseif button.Id == "idRight1" then
									return 1
								elseif button.Id == "idRight2" then
									return total >= 10 and 10
								end
							end,
						}),
						}),
					}),
				PlaceObj('XTemplateWindow', {
					'__context_of_kind', "StorageDepotComponent",
					'__class', "XCheckButton",
					'Id', "idOneStackPerResource",
					'Margins', box(2, 0, 0, 0),
					'LayoutHSpacing', 5,
					'Background', RGBA(255, 255, 255, 0),
					'RelativeFocusOrder', "new-line",
					'OnContextUpdate', function (self, context, ...)
						XCheckButton.OnContextUpdate(self, context, ...)
						local obj = ResolvePropObj(context)
						local single_stack, partial = obj:GetSingleSlotPerRes()
						self:SetCheck(single_stack)
						self:SetIcon(partial and "UI/Hud/ip_button_on_off_2" or "UI/Hud/ip_button_on_off")
					end,
					'FXMouseIn', "ButtonHoverBasic",
					'FXPress', "ButtonClickToggle",
					'FocusedBackground', RGBA(255, 255, 255, 0),
					'RolloverBackground', RGBA(255, 255, 255, 0),
					'PressedBackground', RGBA(255, 255, 255, 0),
					'Icon', "UI/Hud/ip_button_on_off",
					'IconScale', point(700, 700),
					'IconColor', RGBA(255, 255, 255, 255),
					'TextStyle', "TextButton",
					'Translate', true,
					'Text', T(360526126809, --[[ModItemXTemplate tabOverview_Storage_modded Text]] "ﻝﻮﺒﻘﻣ ﺮﺼﻨﻋ ﻞﻜﻟ ﺔﻧﺎﺧ"),
				}, {
					PlaceObj('XTemplateFunc', {
						'name', "OnChange(self, toggled)",
						'func', function (self, toggled)
							StorageSetSingleSlotPerRes(ResolvePropObj(self.context), toggled)
						end,
					}),
					PlaceObj('XTemplateFunc', {
						'name', "OnSetFocus",
						'func', function (self, ...)
							XFrame.OnSetFocus(self, ...)
							local tab = GetDialog(self):ResolveId("idFirstTab")
							local scroll_area = tab and tab:ResolveId("idContent")
							if scroll_area then
								scroll_area:ScrollIntoView(self)
							end
						end,
					}),
					}),
				PlaceObj('XTemplateWindow', {
					'__class', "XCheckButton",
					'Id', "idHighPriority",
					'Margins', box(2, 0, 0, 0),
					'LayoutHSpacing', 5,
					'Background', RGBA(255, 255, 255, 0),
					'RelativeFocusOrder', "new-line",
					'OnContextUpdate', function (self, context, ...)
						XCheckButton.OnContextUpdate(self, context, ...)
						local obj = ResolvePropObj(context)
						local increased, partial = obj:GetIncreasedDemandPriority()
						self:SetCheck(increased)
						self:SetIcon(partial and "UI/Hud/ip_button_on_off_2" or "UI/Hud/ip_button_on_off")
					end,
					'FXMouseIn', "ButtonHoverBasic",
					'FXPress', "ButtonClickToggle",
					'FocusedBackground', RGBA(255, 255, 255, 0),
					'RolloverBackground', RGBA(255, 255, 255, 0),
					'PressedBackground', RGBA(255, 255, 255, 0),
					'Icon', "UI/Hud/ip_button_on_off",
					'IconScale', point(700, 700),
					'IconColor', RGBA(255, 255, 255, 255),
					'TextStyle', "TextButton",
					'Translate', true,
					'Text', T(146081575259, --[[ModItemXTemplate tabOverview_Storage_modded Text]] "ﺎًﻟﻭﺃ ﻥﻮﻫ ﻥﺰّﺧ"),
				}, {
					PlaceObj('XTemplateFunc', {
						'name', "OnChange(self, toggled)",
						'func', function (self, toggled)
							StorageSetHighDemandPriority(ResolvePropObj(self.context), toggled)
						end,
					}),
					PlaceObj('XTemplateFunc', {
						'name', "OnSetFocus",
						'func', function (self, ...)
							XFrame.OnSetFocus(self, ...)
							local tab = GetDialog(self):ResolveId("idFirstTab")
							local scroll_area = tab and tab:ResolveId("idContent")
							if scroll_area then
								scroll_area:ScrollIntoView(self)
							end
						end,
					}),
					}),
				PlaceObj('XTemplateWindow', {
					'__class', "XCheckButton",
					'Id', "idGroupByType",
					'Margins', box(2, 0, 0, 0),
					'LayoutHSpacing', 5,
					'Background', RGBA(255, 255, 255, 0),
					'RelativeFocusOrder', "new-line",
					'FXMouseIn', "ButtonHoverBasic",
					'FXPress', "ButtonClickToggle",
					'FocusedBackground', RGBA(255, 255, 255, 0),
					'RolloverBackground', RGBA(255, 255, 255, 0),
					'PressedBackground', RGBA(255, 255, 255, 0),
					'Icon', "UI/Hud/ip_button_on_off",
					'IconScale', point(700, 700),
					'IconColor', RGBA(255, 255, 255, 255),
					'TextStyle', "TextButton",
					'Translate', true,
					'Text', T(274449302583, --[[ModItemXTemplate tabOverview_Storage_modded Text]] "ﻉﻮﻨﻟﺍ ﺐﺴﺣ ﺮﺻﺎﻨﻌﻟﺍ ﻊﻴﻤﺠﺗ"),
					'Check', true,
				}, {
					PlaceObj('XTemplateFunc', {
						'name', "OnChange(self, toggled)",
						'func', function (self, toggled)
							local mode = toggled and "grouped" or "default"
							self:ResolveId("idInventory"):SetMode(mode)
							InfopanelStorageGroupToggle = toggled
						end,
					}),
					PlaceObj('XTemplateFunc', {
						'name', "OnSetFocus",
						'func', function (self, ...)
							XFrame.OnSetFocus(self, ...)
							local tab = GetDialog(self):ResolveId("idFirstTab")
							local scroll_area = tab and tab:ResolveId("idContent")
							if scroll_area then
								scroll_area:ScrollIntoView(self)
							end
						end,
					}),
					}),
				PlaceObj('XTemplateTemplate', {
					'__template', "VisStorageInventory",
					'Margins', box(0, 0, 5, 0),
				}),
				PlaceObj('XTemplateCode', {
					'comment', "initial group mode",
					'run', function (self, parent, context)
						local obj = ResolvePropObj(context)
						if obj.show_grouped_stacks then
							parent:ResolveId("idInventory"):SetInitialMode("grouped")
						else
							local mode = InfopanelStorageGroupToggle and "grouped" or "default"
							parent:ResolveId("idInventory"):SetInitialMode(mode)
							parent:ResolveId("idGroupByType"):SetCheck(InfopanelStorageGroupToggle)
						end
					end,
				}),
				}),
			PlaceObj('XTemplateTemplate', {
				'__condition', function (parent, context)
					if not _G.CustomDryingRackSlotsEnabled then return false end
					        local obj = ResolvePropObj(context)
					        return IsValid(obj) and (IsKindOf(obj, "DryingRackLarge") or IsKindOf(obj, "DryingRackLarge_ScrapMetal"))
				end,
				'__template', "InfopanelSection",
				'Title', T(953758154130, --[[ModItemXTemplate tabOverview_Storage_modded Title]] "</em><IPVisStorageTotalSlots> / <IPVisStorageFilledSlots><em><right> ﻦﻳﺰﺨﺘﻟﺍ ﺕﺎﻧﺎﺧ"),
			}, {
				PlaceObj('XTemplateWindow', {
					'__class', "XText",
					'HandleMouse', false,
					'TextStyle', "InfopanelText",
					'Text', "48 :ﺔﻴﻘﺒﺘﻤﻟﺍ  48/0 :ﺓﺯﻮﺠﺤﻤﻟﺍ ﺕﺎﻧﺎﺨﻟﺍ",
				}, {
					PlaceObj('XTemplateFunc', {
						'name', "OnContextUpdate(self, context, ...)",
						'func', function (self, context, ...)
							    XText.OnContextUpdate(self, context, ...)
							    local obj = ResolvePropObj(context)
							    if not IsValid(obj) then 
							        self:SetText("Slots Used: 0/48  Remaining: 48")
							        return 
							    end
							    InitializeDryingRackSlotLimits(obj)
							    local total = GetTotalAllocatedSlots(obj) or 0
							    local remaining = 48 - total
							    self:SetText("Slots Reserved: " .. tostring(total) .. "/48  Remaining: " .. tostring(remaining))
						end,
					}),
					PlaceObj('XTemplateFunc', {
						'name', "Open(self, ...)",
						'func', function (self, ...)
							        XText.Open(self, ...)
							        local obj = ResolvePropObj(self.context)
							        if not IsValid(obj) then 
							            self:SetText("Slots Used: 0/48  Remaining: 48")
							            return 
							        end
							        InitializeDryingRackSlotLimits(obj)
							        local total = GetTotalAllocatedSlots(obj) or 0
							        local remaining = 48 - total
							        self:SetText("Slots Reserved: " .. tostring(total) .. "/48  Remaining: " .. tostring(remaining))
						end,
					}),
					}),
				PlaceObj('XTemplateWindow', {
					'Margins', box(0, 2, 0, 2),
					'LayoutMethod', "HList",
					'LayoutHSpacing', 5,
				}, {
					PlaceObj('XTemplateWindow', {
						'__class', "XText",
						'MinWidth', 100,
						'TextStyle', "InfopanelText",
						'Translate', true,
						'Text', T(--[[ModItemXTemplate tabOverview_Storage_modded Text]] "ﻲّﻧ ﺮﻤﺣﺃ ﻢﺤﻟ"),
					}, {
						PlaceObj('XTemplateFunc', {
							'name', "OnContextUpdate(self, context, ...)",
							'func', function (self, context, ...)
								        XText.OnContextUpdate(self, context, ...)
								        local res_def = Resources["RawMeat"]
								        local res_icon = res_def.icon and T{816548804161, "<res_icon(res)> ", res = "RawMeat"} or ""
								        self:SetText(res_icon .. res_def.display_name)
							end,
						}),
						PlaceObj('XTemplateFunc', {
							'name', "Open(self, ...)",
							'func', function (self, ...)
								        XText.Open(self, ...)
								        local res_def = Resources["RawMeat"]
								        local res_icon = res_def.icon and T{816548804161, "<res_icon(res)> ", res = "RawMeat"} or ""
								        self:SetText(res_icon .. res_def.display_name)
							end,
						}),
						}),
					PlaceObj('XTemplateWindow', {
						'Margins', box(25, 0, 0, 0),
					}),
					PlaceObj('XTemplateTemplate', {
						'__template', "AmountControl",
						'HAlign', "right",
						'PressFunc', "UIChangeRawMeatSlots",
					}, {
						PlaceObj('XTemplateFunc', {
							'name', "GetUIAmountText",
							'func', function (self, ...)
								    local obj = ResolvePropObj(self.context)
								    if not IsValid(obj) then return 0 end
								    return GetCustomSlotLimit(obj, "RawMeat") or 0
							end,
						}),
						PlaceObj('XTemplateFunc', {
							'name', "GetUIAmount(self, button)",
							'func', function (self, button)
								    if button.Id == "idLeft1" then
								        return -10
								    elseif button.Id == "idLeft2" then
								        return -1
								    elseif button.Id == "idRight1" then
								        return 1
								    elseif button.Id == "idRight2" then
								        return 10
								    end
								    return 0
							end,
						}),
						}),
					}),
				PlaceObj('XTemplateWindow', {
					'Margins', box(0, 2, 0, 2),
					'LayoutMethod', "HList",
					'LayoutHSpacing', 5,
				}, {
					PlaceObj('XTemplateWindow', {
						'__class', "XText",
						'MinWidth', 100,
						'TextStyle', "InfopanelText",
						'Translate', true,
						'Text', T(935261045110, --[[ModItemXTemplate tabOverview_Storage_modded Text]] "ﺀﺎﻔﺧﺇ"),
					}, {
						PlaceObj('XTemplateFunc', {
							'name', "OnContextUpdate(self, context, ...)",
							'func', function (self, context, ...)
								        XText.OnContextUpdate(self, context, ...)
								        local res_def = Resources["LeatherRaw"]
								        local res_icon = res_def.icon and T{816548804161, "<res_icon(res)> ", res = "LeatherRaw"} or ""
								        self:SetText(res_icon .. res_def.display_name)
							end,
						}),
						PlaceObj('XTemplateFunc', {
							'name', "Open(self, ...)",
							'func', function (self, ...)
								        XText.Open(self, ...)
								        local res_def = Resources["LeatherRaw"]
								        local res_icon = res_def.icon and T{816548804161, "<res_icon(res)> ", res = "LeatherRaw"} or ""
								        self:SetText(res_icon .. res_def.display_name)
							end,
						}),
						}),
					PlaceObj('XTemplateWindow', {
						'Margins', box(78, 0, 0, 0),
						'HAlign', "right",
					}),
					PlaceObj('XTemplateTemplate', {
						'__template', "AmountControl",
						'HAlign', "right",
						'PressFunc', "UIChangeLeatherRawSlots",
					}, {
						PlaceObj('XTemplateFunc', {
							'name', "GetUIAmountText",
							'func', function (self, ...)
								    local obj = ResolvePropObj(self.context)
								    if not IsValid(obj) then return 0 end
								    return GetCustomSlotLimit(obj, "LeatherRaw") or 0
							end,
						}),
						PlaceObj('XTemplateFunc', {
							'name', "GetUIAmount(self, button)",
							'func', function (self, button)
								    if button.Id == "idLeft1" then
								        return -10
								    elseif button.Id == "idLeft2" then
								        return -1
								    elseif button.Id == "idRight1" then
								        return 1
								    elseif button.Id == "idRight2" then
								        return 10
								    end
								    return 0
							end,
						}),
						}),
					}),
				PlaceObj('XTemplateWindow', {
					'Margins', box(0, 2, 0, 2),
					'LayoutMethod', "HList",
					'LayoutHSpacing', 5,
				}, {
					PlaceObj('XTemplateWindow', {
						'__class', "XText",
						'MinWidth', 100,
						'TextStyle', "InfopanelText",
						'Translate', true,
						'Text', T(455803091688, --[[ModItemXTemplate tabOverview_Storage_modded Text]] "ﻲّﻨﻟﺍ ﻦﻴﺧﺪﺘﻟﺍ ﻕﺭﻭ"),
					}, {
						PlaceObj('XTemplateFunc', {
							'name', "OnContextUpdate(self, context, ...)",
							'func', function (self, context, ...)
								        XText.OnContextUpdate(self, context, ...)
								        local res_def = Resources["SmokeleafRaw"]
								        local res_icon = res_def.icon and T{816548804161, "<res_icon(res)> ", res = "SmokeleafRaw"} or ""
								        self:SetText(res_icon .. res_def.display_name)
							end,
						}),
						PlaceObj('XTemplateFunc', {
							'name', "Open(self, ...)",
							'func', function (self, ...)
								        XText.Open(self, ...)
								        local res_def = Resources["SmokeleafRaw"]
								        local res_icon = res_def.icon and T{816548804161, "<res_icon(res)> ", res = "SmokeleafRaw"} or ""
								        self:SetText(res_icon .. res_def.display_name)
							end,
						}),
						}),
					PlaceObj('XTemplateWindow', {
						'Margins', box(15, 0, 0, 0),
						'HAlign', "right",
					}),
					PlaceObj('XTemplateTemplate', {
						'__template', "AmountControl",
						'HAlign', "right",
						'PressFunc', "UIChangeSmokeleafRawSlots",
					}, {
						PlaceObj('XTemplateFunc', {
							'name', "GetUIAmountText",
							'func', function (self, ...)
								    local obj = ResolvePropObj(self.context)
								    if not IsValid(obj) then return 0 end
								    return GetCustomSlotLimit(obj, "SmokeleafRaw") or 0
							end,
						}),
						PlaceObj('XTemplateFunc', {
							'name', "GetUIAmount(self, button)",
							'func', function (self, button)
								    if button.Id == "idLeft1" then
								        return -10
								    elseif button.Id == "idLeft2" then
								        return -1
								    elseif button.Id == "idRight1" then
								        return 1
								    elseif button.Id == "idRight2" then
								        return 10
								    end
								    return 0
							end,
						}),
						}),
					}),
				PlaceObj('XTemplateWindow', {
					'__class', "XCheckButton",
					'Id', "idHighPriority",
					'Margins', box(2, 0, 0, 0),
					'LayoutHSpacing', 5,
					'Background', RGBA(255, 255, 255, 0),
					'RelativeFocusOrder', "new-line",
					'OnContextUpdate', function (self, context, ...)
						XCheckButton.OnContextUpdate(self, context, ...)
						local obj = ResolvePropObj(context)
						local increased, partial = obj:GetIncreasedDemandPriority()
						self:SetCheck(increased)
						self:SetIcon(partial and "UI/Hud/ip_button_on_off_2" or "UI/Hud/ip_button_on_off")
					end,
					'FXMouseIn', "ButtonHoverBasic",
					'FXPress', "ButtonClickToggle",
					'FocusedBackground', RGBA(255, 255, 255, 0),
					'RolloverBackground', RGBA(255, 255, 255, 0),
					'PressedBackground', RGBA(255, 255, 255, 0),
					'Icon', "UI/Hud/ip_button_on_off",
					'IconScale', point(700, 700),
					'IconColor', RGBA(255, 255, 255, 255),
					'TextStyle', "TextButton",
					'Translate', true,
					'Text', T(807799905840, --[[ModItemXTemplate tabOverview_Storage_modded Text]] "ﺎًﻟﻭﺃ ﻥﻮﻫ ﻥﺰّﺧ"),
				}, {
					PlaceObj('XTemplateFunc', {
						'name', "OnChange(self, toggled)",
						'func', function (self, toggled)
							StorageSetHighDemandPriority(ResolvePropObj(self.context), toggled)
						end,
					}),
					PlaceObj('XTemplateFunc', {
						'name', "OnSetFocus",
						'func', function (self, ...)
							XFrame.OnSetFocus(self, ...)
							local tab = GetDialog(self):ResolveId("idFirstTab")
							local scroll_area = tab and tab:ResolveId("idContent")
							if scroll_area then
								scroll_area:ScrollIntoView(self)
							end
						end,
					}),
					}),
				PlaceObj('XTemplateWindow', {
					'__class', "XCheckButton",
					'Id', "idGroupByType",
					'Margins', box(2, 0, 0, 0),
					'LayoutHSpacing', 5,
					'Background', RGBA(255, 255, 255, 0),
					'RelativeFocusOrder', "new-line",
					'FXMouseIn', "ButtonHoverBasic",
					'FXPress', "ButtonClickToggle",
					'FocusedBackground', RGBA(255, 255, 255, 0),
					'RolloverBackground', RGBA(255, 255, 255, 0),
					'PressedBackground', RGBA(255, 255, 255, 0),
					'Icon', "UI/Hud/ip_button_on_off",
					'IconScale', point(700, 700),
					'IconColor', RGBA(255, 255, 255, 255),
					'TextStyle', "TextButton",
					'Translate', true,
					'Text', T(180614108975, --[[ModItemXTemplate tabOverview_Storage_modded Text]] "ﻉﻮﻨﻟﺍ ﺐﺴﺣ ﺮﺻﺎﻨﻌﻟﺍ ﻊﻴﻤﺠﺗ"),
					'Check', true,
				}, {
					PlaceObj('XTemplateFunc', {
						'name', "OnChange(self, toggled)",
						'func', function (self, toggled)
							local mode = toggled and "grouped" or "default"
							self:ResolveId("idInventory"):SetMode(mode)
							InfopanelStorageGroupToggle = toggled
						end,
					}),
					PlaceObj('XTemplateFunc', {
						'name', "OnSetFocus",
						'func', function (self, ...)
							XFrame.OnSetFocus(self, ...)
							local tab = GetDialog(self):ResolveId("idFirstTab")
							local scroll_area = tab and tab:ResolveId("idContent")
							if scroll_area then
								scroll_area:ScrollIntoView(self)
							end
						end,
					}),
					}),
				PlaceObj('XTemplateTemplate', {
					'__template', "VisStorageInventory",
					'Margins', box(0, 0, 5, 0),
				}),
				PlaceObj('XTemplateCode', {
					'comment', "initial group mode",
					'run', function (self, parent, context)
						local obj = ResolvePropObj(context)
						if obj.show_grouped_stacks then
							parent:ResolveId("idInventory"):SetInitialMode("grouped")
						else
							local mode = InfopanelStorageGroupToggle and "grouped" or "default"
							parent:ResolveId("idInventory"):SetInitialMode(mode)
							parent:ResolveId("idGroupByType"):SetCheck(InfopanelStorageGroupToggle)
						end
					end,
				}),
				}),
			}),
	}),
	}),
PlaceObj('ModItemOptionToggle', {
	'name', "FasterAnimalLeading",
	'DisplayName', "ﺔﻋﺮﺴﺑ ﺔﺿﻭّﺮﻤﻟﺍ ﺕﺎﻧﺍﻮﻴﺤﻟﺍ ﺓﺩﺎﻴﻗ",
	'Help', ".ﻢﻬﻘﺤﻠﺗ ﻥﺎﺸﻣ ﻉﺮّﺴﺘﺑ ﺕﺎﻧﺍﻮﻴﺤﻟﺍﻭ ،ﺔﺿﻭّﺮﻤﻟﺍ ﺕﺎﻧﺍﻮﻴﺤﻟﺍ ﺓﺩﺎﻴﻗ ﺪﻨﻋ ﺍﻮﻀﻛﺮﻴﺑ ﻥﻮﺟﺎﻨﻟﺍ",
	'DefaultValue', true,
}),
PlaceObj('ModItemCode', {
	'name', "FasterAnimalLeading",
	'CodeFileName', "Code/FasterAnimalLeading.lua",
}),
PlaceObj('ModItemFolder', {
	'name', "Devices Immediate Interaction",
}, {
	PlaceObj('ModItemOptionToggle', {
		'name', "EnableImmediateDeviceInteraction",
		'DisplayName', "ﺓﺰﻬﺟﻷﺎﺑ ﻱﺭﻮﻔﻟﺍ ﻢﻜﺤﺘﻟﺍ",
		'Help', ".ﻞﻣﺎﻋ ﻰﻨﺘﺴﺗ ﺎﻣ ﻥﻭﺪﺑ ،ﺎﻫﺮﻴﻏﻭ ﺓﺭﺍﺮﺤﻟﺍﻭ ﺮﺋﺍﻭﺪﻟﺍﻭ ﺀﺎﺑﺮﻬﻜﻟﺍ ﺓﺰﻬﺟﺄﺑ ﻱﺭﻮﻓ ﻢﻜّﺤﺗ",
	}),
	PlaceObj('ModItemOptionToggle', {
		'name', "EnableImmediateWindowGateInteraction",
		'DisplayName', "ﺕﺎﺑﺍﻮﺒﻟﺍﻭ ﺬﻓﺍﻮﻨﻟﺎﺑ ﻱﺭﻮﻔﻟﺍ ﻢﻜﺤﺘﻟﺍ",
		'Help', ".ﻞﻣﺎﻋ ﻞﺧﺪﺗ ﻥﻭﺪﺑ ﺍًﺭﻮﻓ ﺕﺎﺑﺍﻮﺒﻟﺍﻭ ﺬﻓﺍﻮﻨﻟﺍ ﻕﻼﻏﺇﻭ ﺢﺘﻓ",
	}),
	PlaceObj('ModItemOptionToggle', {
		'name', "EnableImmediateTrapInteraction",
		'DisplayName', "ﺥﺎﺨﻔﻟﺎﺑ ﻱﺭﻮﻔﻟﺍ ﻢﻜﺤﺘﻟﺍ",
		'Help', ".ﻞﻣﺎﻋ ﻞﺧﺪﺗ ﻥﻭﺪﺑ ﺍًﺭﻮﻓ ﺎﻬﻠﻴﻄﻌﺗﻭ ﺥﺎﺨﻔﻟﺍ ﻞﻴﻌﻔﺗ",
	}),
	PlaceObj('ModItemOptionToggle', {
		'name', "EnableImmediateForceFieldInteraction",
		'DisplayName', "ﺓﻮﻘﻟﺍ ﻝﻮﻘﺤﺑ ﻱﺭﻮﻔﻟﺍ ﻢﻜﺤﺘﻟﺍ",
		'Help', ".ﻞﻣﺎﻋ ﻞﺧﺪﺗ ﻥﻭﺪﺑ ﺍًﺭﻮﻓ ﺓﻮﻘﻟﺍ ﻝﻮﻘﺣ ﺀﺎﻔﻃﺇﻭ ﻞﻴﻐﺸﺗ",
	}),
	PlaceObj('ModItemCode', {
		'name', "ImmediateInteractions.lua",
		'CodeFileName', "Code/ImmediateInteractions.lua.lua",
	}),
	}),
}
