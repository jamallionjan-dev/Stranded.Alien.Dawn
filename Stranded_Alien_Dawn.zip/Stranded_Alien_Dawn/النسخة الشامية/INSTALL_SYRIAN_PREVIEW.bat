@echo off
setlocal EnableExtensions
title Syrian localization preview - install only
cd /d "%~dp0"
set "SRC=%~dp0SAD_Syrian_Localization_vNext"
set "DST=%APPDATA%\Stranded - Alien Dawn\Mods\SAD_Syrian_Localization_vNext"
if not exist "%SRC%\metadata.lua" (
  echo ERROR: Extract the ZIP fully first. Mod folder missing.
  pause
  exit /b 1
)
if exist "%DST%" (
  echo Existing Syrian mod found: %DST%
  echo To protect your previous test version, back it up and remove it before installing this new one.
  echo The older stable Arabic mod is NOT changed.
  pause
  exit /b 1
)
if not exist "%APPDATA%\Stranded - Alien Dawn\Mods" mkdir "%APPDATA%\Stranded - Alien Dawn\Mods"
xcopy "%SRC%\*" "%DST%\" /E /I /Y >nul
if errorlevel 1 (
  echo ERROR: The mod could not be copied. Install manually using README_AR.txt.
  pause
  exit /b 1
)
echo Syrian preview copied. Installing Arial fonts from this Windows PC...
call "%DST%\INSTALL_ARABIC_FONT.bat"
echo IMPORTANT: Set game language to English, disable old Arabic mod, enable SADSHAM01 and restart game.
pause
