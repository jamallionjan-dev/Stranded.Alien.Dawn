return PlaceObj("ModDef", {
  "title", "ترجمة Stranded: Alien Dawn للعربية",
  "description", "ترجمة عربية للعبة Stranded: Alien Dawn مع دعم الخط العربي وإصلاح اتجاه النصوص الطويلة.",
  "id", "SADAR11",
  "author", "Jamal",
  "version_major", 0,
  "version_minor", 11,
  "version", 11,
  "lua_revision", 373414,
  "saved_with_revision", 373414,
  "saved", 0,
})
