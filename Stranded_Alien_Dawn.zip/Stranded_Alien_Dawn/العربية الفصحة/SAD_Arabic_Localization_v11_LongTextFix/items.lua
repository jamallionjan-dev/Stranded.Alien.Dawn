return {
  PlaceObj("ModItemFont", {
    "AssetFiles", {
      PlaceObj("FontAsset", { "FontPath", "Mod/SADAR11/Fonts/arial.ttf" }),
      PlaceObj("FontAsset", { "FontPath", "Mod/SADAR11/Fonts/arialbd.ttf" }),
      PlaceObj("FontAsset", { "FontPath", "Mod/SADAR11/Fonts/ariali.ttf" }),
      PlaceObj("FontAsset", { "FontPath", "Mod/SADAR11/Fonts/arialbi.ttf" }),
    },
    "ReplaceMappings", {
      PlaceObj("FontReplaceMapping", { "Replace", "SchemeBk", "With", "Arial" }),
      PlaceObj("FontReplaceMapping", { "Replace", "LibelSuitRg", "With", "Arial" }),
    },
  }),
  PlaceObj("ModItemLocTable", {
    "language", "English",
    "filename", "Locales/Game_AR.csv",
  }),
}
