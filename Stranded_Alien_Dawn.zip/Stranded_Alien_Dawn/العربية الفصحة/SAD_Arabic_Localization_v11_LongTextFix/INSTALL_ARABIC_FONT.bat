@echo off
setlocal
cd /d "%~dp0"
echo [ترجمة Stranded: Alien Dawn للعربية v0.11] Copying Windows Arial fonts...
if not exist "Fonts" mkdir "Fonts"
for %%F in (arial.ttf arialbd.ttf ariali.ttf arialbi.ttf) do (
  if exist "%WINDIR%\Fonts\%%F" (
    copy /Y "%WINDIR%\Fonts\%%F" "Fonts\%%F" >nul
    echo   OK: %%F
  ) else (
    echo   MISSING: %%F
  )
)
echo.
echo Done. Start the game, keep Language = English,
echo enable "ترجمة Stranded: Alien Dawn للعربية", then restart once.
pause
